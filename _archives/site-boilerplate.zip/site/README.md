# Site boilerplate — structure only, no final design

Real, working pages (no build step) that demonstrate the site's structure and
navigation behaviour, ahead of visual design.

## Run it locally

fetch() needs http(s), not file://, so serve the folder instead of opening
index.html directly:

    python3 -m http.server 8000

Then visit http://localhost:8000/

## Structure

    /                      splash only (Nathan Chapman / Tidbits)
    /nathan/               personal home: blurb + featured posts
    /nathan/about/
    /nathan/blog/          post listing (placeholder cards)
    /nathan/contact/
    /tidbits/              studio home: featured image + recent work
    /tidbits/about/
    /tidbits/portfolio/    project grid (placeholder cards)
    /tidbits/contact/

    css/base.css           shared structural rules (layout, spacing, grid,
                            nav, footer) — identical for both sites
    css/theme-nathan.css   Nathan palette/type (white/black/orange #ff9711,
                            thin weight placeholder)
    css/theme-tidbits.css  Tidbits palette/type (dark bg, 5-colour accent
                            set, bold placeholder)
    js/router.js           pjax-style client-side router

## How the interaction works

- `/` shows **only** the splash — two full-height halves, no nav, no footer,
  nothing else on screen.
- Clicking a half is the one piece of JS on the whole site (`js/router.js`).
  It fetches the target page, drops its nav/content/footer in underneath
  the splash, updates the URL via `history.pushState` (no reload), and
  smooth-scrolls down so the new nav lands right at the top of the
  viewport. Once that settles, the splash collapses and is removed from
  the page entirely — from that point on you're on a genuine `/nathan/`
  or `/tidbits/` page with no splash anywhere in the DOM, same as if
  you'd loaded it directly.
- Every other link on the site — the swap button, the About/Blog/Portfolio/
  Contact menu — is a plain `<a href>`. Clicking them is a completely
  normal, full page load. No JS, nothing to break, nothing clever.
- Because every route is also a real, standalone HTML page, none of this
  JS is required to browse the site — it's a progressive enhancement on
  top of ordinary navigation.

## Mapping to Kirby later

This structure translates close to 1:1 onto Kirby:

- Each folder here (`nathan/`, `nathan/blog/`, `tidbits/portfolio/`, etc.)
  becomes a Kirby page in `content/`.
- `#splash`, `#sitenav`, `#sitefooter` become Kirby **snippets**, included
  in every template, instead of being duplicated per HTML file as they are
  here.
- The two `theme-*.css` files stay as-is; the `data-theme` attribute gets
  set from a template/field in Kirby rather than hardcoded per file.
- `router.js` doesn't need to change — Kirby-rendered pages are still just
  HTML at real URLs, which is all the router requires.

## Known placeholders (intentional, for structure only)

- Font stacks reference placeholder names — real typefaces come in the
  design pass.
- All copy is bracketed placeholder text.
- All images are labelled grey boxes (`.placeholder-box`).
- Contact forms have no backend wired up yet.
