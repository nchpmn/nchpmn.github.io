<?php

use Kirby\Cms\Page;
use Kirby\Form\Form;

/**
 * Page
 */
return [
	'fields' => [
		'blueprint'   => fn (Page $page) => $page->blueprint(),
		'blueprints'  => fn (Page $page) => $page->blueprints(),
		'children'    => fn (Page $page) => $page->children()->filter('isListable', true),
		'content'     => fn (Page $page) => Form::for($page)->toFormValues(),
		'drafts'      => fn (Page $page) => $page->drafts()->filter('isListable', true),
		'errors'      => fn (Page $page) => $page->errors(),
		'files'       => fn (Page $page) => $page->files()->sorted()->filter('isListable', true),
		'hasChildren' => fn (Page $page) => $page->hasChildren(),
		'hasDrafts'   => fn (Page $page) => $page->hasDrafts(),
		'hasFiles'    => fn (Page $page) => $page->hasFiles(),
		'id'          => fn (Page $page) => $page->id(),
		'isSortable'  => fn (Page $page) => $page->isSortable(),
		'num'     	  => fn (Page $page) => $page->num(),
		'options' 	  => fn (Page $page) => $page->panel()->options(['preview']),
		'panelImage'  => fn (Page $page) => $page->panel()->image(),
		'parent'      => function (Page $page) {
			$parent = $page->parent();

			if ($parent === null || $parent->isListable() === false) {
				return null;
			}

			return $parent;
		},
		'parents'     => fn (Page $page) => $page->parents()->flip()->filter('isListable', true),
		'previewUrl'  => fn (Page $page) => $page->previewUrl(),
		'siblings'    => function (Page $page) {
			if ($page->isDraft() === true) {
				$siblings = $page->parentModel()->children()->not($page);
			} else {
				$siblings = $page->siblings();
			}

			return $siblings->filter('isListable', true);
		},
		'slug'     => fn (Page $page) => $page->slug(),
		'status'   => fn (Page $page) => $page->status(),
		'template' => fn (Page $page) => $page->intendedTemplate()->name(),
		'title'    => fn (Page $page) => $page->title()->value(),
		'url'      => fn (Page $page) => $page->url(),
		'uuid'     => fn (Page $page) => $page->uuid()?->toString()
	],
	'type' => Page::class,
	'views' => [
		'compact' => [
			'id',
			'title',
			'url',
			'num',
			'uuid'
		],
		'default' => [
			'content',
			'id',
			'status',
			'num',
			'options',
			'parent' => 'compact',
			'slug',
			'template',
			'title',
			'url',
			'uuid'
		],
		'panel' => [
			'id',
			'blueprint',
			'content',
			'status',
			'options',
			'parents' => ['id', 'slug', 'title'],
			'previewUrl',
			'slug',
			'title',
			'url',
			'uuid'
		],
		'selector' => [
			'id',
			'title',
			'parent' => [
				'id',
				'title'
			],
			'children' => [
				'hasChildren',
				'id',
				'panelIcon',
				'panelImage',
				'title',
			],
		]
	],
];
