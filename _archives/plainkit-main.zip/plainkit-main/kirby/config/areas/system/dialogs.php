<?php

use Kirby\Cms\App;
use Kirby\Cms\LicenseType;
use Kirby\Exception\LogicException;
use Kirby\Panel\Field;
use Kirby\Toolkit\I18n;

return [
	// license key
	'license' => [
		'load' => function () {
			$kirby      = App::instance();
			$license    = $kirby->system()->license();
			$obfuscated = $kirby->user()->isAdmin() === false;
			$status     = $license->status();
			$renewable  = $status->renewable();

			return [
				'component' => 'k-license-dialog',
				'props' => [
					'license' => [
						'code'   => $license->code($obfuscated),
						'domain' => $license->domain(),
						'icon'   => $status->icon(),
						'info'   => $status->info($license->renewal('Y-m-d', 'date')),
						'theme'  => $status->theme(),
						'type'   => $license->label(),
					],
					'cancelButton' => $renewable,
					'submitButton' => $renewable ? [
						'icon'  => 'refresh',
						'text'  => I18n::translate('renew'),
						'theme' => 'love',
					] : false,
				]
			];
		},
		'submit' => function () {
			// @codeCoverageIgnoreStart
			$response = App::instance()->system()->license()->upgrade();

			// the upgrade is still needed
			if ($response['status'] === 'upgrade') {
				return [
					'redirect' => $response['url']
				];
			}

			// the upgrade has already been completed
			if ($response['status'] === 'complete') {
				return [
					'event'   => 'system.renew',
					'message' => I18n::translate('license.success')
				];
			}

			throw new LogicException(message: 'The upgrade failed');
			// @codeCoverageIgnoreEnd
		}
	],
	'license/remove' => [
		'load' => function () {
			return [
				'component' => 'k-remove-dialog',
				'props' => [
					'text' => I18n::translate('license.remove.text'),
					'size' => 'medium',
					'submitButton' => [
						'icon'  => 'trash',
						'text'  => I18n::translate('remove'),
						'theme' => 'negative',
					],
				]
			];
		},
		'submit' => function () {
			// @codeCoverageIgnoreStart
			App::instance()->system()->license()->delete();
			return true;
			// @codeCoverageIgnoreEnd
		}
	],
	// license registration
	'registration' => [
		'load' => function () {
			$system = App::instance()->system();
			$local  = $system->isLocal();

			return [
				'component' => 'k-form-dialog',
				'props' => [
					'fields' => [
						'domain' => [
							'label' => I18n::translate('domain'),
							'type'  => 'info',
							'theme' => 'white',
							'icon'  => 'info',
							'text'  => I18n::template('license.activate.domain', ['host' => $system->indexUrl()]),
						],
						'type' => [
							'label'    => I18n::translate('license.activate.label'),
							'type'     => 'toggles',
							'required' => true,
							'labels'   => true,
							'grow'     => true,
							'options'  => [
								[
									'icon'  => 'globe',
									'text'  => I18n::translate('license.regular.label'),
									'value' => 'regular'
								],
								[
									'icon'  => 'key',
									'text'  => I18n::translate('license.free.label'),
									'value' => 'free'
								]
							],
						],
						'warning' => [
							'type'  => 'info',
							'theme' => 'warning',
							'text'  => I18n::template('license.activate.' . ($local ? 'local' : 'public'), ['host' => $system->indexUrl()]),
							'when'  => ['type' => $local ? 'regular' : 'free'],
						],
						'acknowledge' => [
							'when'     => ['type' => 'free'],
							'label'    => I18n::translate('license.activate.acknowledge.label'),
							'type'     => 'toggle',
							'text'     => I18n::translate('license.activate.acknowledge.text'),
							'required' => true,
							'help'     => I18n::template('license.activate.acknowledge.help', [
								'url' => 'https://getkirby.com/license/free-licenses'
							]),
						],
						'license' => [
							'when'        => ['type' => 'regular'],
							'label'       => I18n::translate('license.code.label'),
							'type'        => 'text',
							'required'    => true,
							'counter'     => false,
							'placeholder' => 'K-',
							'help'        => I18n::translate('license.code.help') . ' ' . '<a href="https://getkirby.com/buy" target="_blank">' . I18n::translate('license.buy') . ' &rarr;</a>'
						],
						'email' => Field::email([
							'when'     => ['type' => 'regular'],
							'required' => true
						])
					],
					'submitButton' => [
						'icon'  => 'key',
						'text'  => I18n::translate('activate'),
						'theme' => 'love',
					],
					'value' => [
						'license' => null,
						'email'   => null,
						'type'    => 'regular',
					]
				]
			];
		},
		'submit' => function () {
			// @codeCoverageIgnoreStart
			$kirby   = App::instance();
			$type    = $kirby->request()->get('type', 'regular');
			$email   = $kirby->request()->get('email');
			$license = match ($type) {
				'free'  => LicenseType::Free->prefix(),
				default => $kirby->request()->get('license')
			};

			$kirby->system()->register($license, $email);

			return [
				'event'   => 'system.register',
				'message' => match ($type) {
					'free'  => I18n::translate('license.success.free'),
					default => I18n::translate('license.success')
				}
			];
			// @codeCoverageIgnoreEnd
		}
	],
];
