# nchp.mn - Kirby project

Working Kirby install with real blueprints, content structure, and the
roughed-in design carried over from the static prototype. This is meant
to be clicked around in the Panel and previewed locally - it is **not**
yet on the homelab, and the fancy visual design pass hasn't happened.

## Run it locally

Kirby's core code isn't included in this zip (it's ~40MB of vendored
code you don't need from me - you'll fetch it yourself, same as any
dependency):

```
./setup.sh
```

This uses Composer if you have it, otherwise falls back to pulling
Kirby's core straight from GitHub. Either way, you'll end up with a
`kirby/` folder alongside this README.

Then:

```
php -S localhost:8000 kirby/router.php
```

Visit `http://localhost:8000` for the site, or
`http://localhost:8000/panel` to create your first admin account and
start editing content in the Panel.

## What's here

```
content/                   your actual content, as flat files
  home/                     the splash page ("/")
  nathan/                   personal site
    nathan-home.txt
    about/
    blog/
      1_first-post/         "1_" just controls sort order, not the URL
      2_second-post/
    contact/
  tidbits/                 Tidbits site
    tidbits-home.txt
    about/
    projects/
      1_project-one/
      2_project-two/
    contact/

site/
  blueprints/pages/         Panel field definitions, one per content type
  templates/                PHP templates - one per blueprint, mostly
                             thin wrappers that pull in shared snippets
  snippets/                 head.php, nav.php, footer.php, plus
                             about-body.php / contact-body.php (shared
                             between Nathan and Tidbits, since those two
                             page types are structurally identical)
  plugins/helpers/          small helper to turn a Vimeo/YouTube URL into
                             an embeddable src (used by the Tidbits
                             showreel and portfolio item video field)

assets/css/, assets/js/     the exact CSS/JS from the static prototype,
                             unchanged, plus a handful of new rules for
                             pieces that didn't exist in the prototype
                             (showreel background, portfolio hover grid,
                             footer links)
```

## How the content architecture maps to blueprints

This follows exactly what we defined:

- **Nathan homepage** (`nathan-home`): title, subtitle, blurb, plus an
  auto-generated "Featured posts" list (latest 4 articles, thumbnail
  shown only on the first one - matches your "homepage only" rule).
- **Nathan about** (`nathan-about`): title, summary, featured photo,
  main content (Blocks field).
- **Article** (`article`): title, date, blurb, thumbnail, body (Blocks).
  Used as children of the blog index page.
- **Nathan blog index** (`nathan-blog`): lists all articles, thumbnail
  always shown (per your `/blog` rule).
- **Tidbits homepage** (`tidbits-home`): showreel embed URL, logo, plus
  an auto-generated portfolio grid (latest 6 items). About link and
  scroll-to-portfolio link are structural, not editable fields.
- **Tidbits about** (`tidbits-about`): same shape as Nathan's about.
- **Portfolio item** (`portfolio-item`): title, date, blurb, a
  video/photo toggle for the featured media, thumbnail (for grids), body
  (Blocks).
- **Tidbits projects index** (`tidbits-projects`): lists all portfolio
  items as thumbnail-only cards; title + date reveal on hover.
- **Contact** (`nathan-contact` / `tidbits-contact`): title + intro text
  above a (currently non-functional) contact form.
- **Site-wide footer** (`site.yml`, under Site Settings in the Panel):
  footer text, copyright text, and a repeatable links list (labels TBC,
  as discussed).

## Known gaps / what's still rough

- **Contact forms don't submit anywhere yet** - that needs an actual
  handler (e.g. a small Kirby route + email, or a third-party form
  service). Worth deciding once we're back on the tech side of things.
- **Showreel/portfolio video embeds** are functional but visually rough
  - a real iframe, autoplay/loop/muted params set, but no polish on
  cropping/sizing to guarantee edge-to-edge coverage without letterboxing
  on odd aspect ratios. Flagged for the design pass, as discussed.
- **No real images uploaded** - every image field will show empty/
  placeholder-box until you upload something through the Panel.
- **Kirby's own license** - still on you to confirm per our earlier
  conversation; this only matters once this goes into real production
  use, not for local testing.

## Not yet done (next steps from here)

- Standing this up on the homelab (Docker) instead of your local machine.
- Wiring up the `kirby-static-site-generator` plugin and the one-click
  "Publish to Live Site" Panel button.
- The actual visual design pass - fonts, imagery, spacing, the showreel
  polish mentioned above.
