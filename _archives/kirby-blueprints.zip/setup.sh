#!/bin/sh
# Fetches Kirby core so you can preview this project locally.
#
# If you have Composer, that's the standard/recommended way - it'll also
# manage version updates properly:
#
#   composer install
#
# This script is a fallback for testing without Composer installed - it
# just clones the same core code directly from GitHub.

set -e

if [ -d "kirby" ]; then
  echo "kirby/ already exists - skipping."
  exit 0
fi

if command -v composer >/dev/null 2>&1; then
  echo "Composer found - running composer install..."
  composer install
else
  echo "No Composer found - cloning Kirby core from GitHub instead..."
  git clone --depth 1 https://github.com/getkirby/kirby.git kirby
  rm -rf kirby/.git
fi

echo "Done. Run: php -S localhost:8000 kirby/router.php"
echo "Then visit http://localhost:8000 to preview, or http://localhost:8000/panel to set up an admin account."
